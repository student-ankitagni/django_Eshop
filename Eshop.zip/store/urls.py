from django.urls import path
from .views import Index,Login,Signup,logout,Cart,CheckOut,Orders
from .auth import auth_middleware




urlpatterns = [
    path('',Index.as_view(),name='home'),
    # method based signup views===========
    #path('signup',signup),
    # class based login views============
    path('login',Login.as_view(),name='login'),
    # class based login views============
    path('signup',Signup.as_view(),name='signup'),
    # method based login views===========
    #path('login',login)
    
    path('logout',logout,name='logout'),
    path('cart',Cart.as_view(),name='cart'),
    path('checkout',CheckOut.as_view(),name='checkout'),
    path('orders',auth_middleware(Orders.as_view()),name='oreders')
]